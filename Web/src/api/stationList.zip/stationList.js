export const stationList = {
  line1: ["수원"],
  line2: ["왕십리"],
  line4: ["혜화"],
  line5: ["신금호", "왕십리"],
};
// 혜화 4호선
// 수원 1호선
// 신금호 5호선
// 왕십리역 5/2호선
