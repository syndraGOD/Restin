const data = [
  //가게 하나
  {
    UUID: "", //입력X, 고유DB인식코드
    id: 1, //가게 고유번호, 1~ 순차적으로증가
    signDate: null, //수정X, 가게를 Restin에 등록한 날짜
    name: "호우수원",
    storeOwnerName: "홍길동",
    accountHolder: "홍길동",
    settlementAccount: "00-0000-0000-00",
    unitPrice: 500,
    location: "경기 수원시 팔달구 덕영대로895번길 20 1층 호우수원",
    subwayStation: "수원",
    distance: 700, // 네이버지도에서 하드넘버 가져오기 or 내위치(GPS)와 location 거리 계산값
    walkingTime: 5, // 분 단위 - distance값 나누기 75_소수점버림
    businessTime: {
      //null 이면 그날 휴무,
      // open : null 이면 close도 null이어야함
      monopen: null, //ex : "0930"
      monclose: null, //ex : "1800"
      monbreak: [
        ["1100", "0200"],
        ["1500", "0100"],
      ],
      //ex : [["1300", "0200",],], 또는 [["1100", "0200",], ["1500", "0100",],],
      //["break시작시간", "break지속시간"] 위 사례에서는 13시부터 2시간동안 브레이크 타임
      tueopen: null,
      tueclose: null,
      tuebreak: [],
      wedopen: null,
      wedclose: null,
      wedbreak: [],
      thuopen: null,
      thuclose: null,
      thubreak: [],
      friopen: null,
      friclose: null,
      fribreak: [],
      satopen: null,
      satclose: null,
      satbreak: [],
      sunopen: null,
      sunclose: null,
      sunbreak: [],
    },
    BusinessState: true, // true = 기본값, false = 휴폐업 또는 일시정지
    BusinessAdminPause: ["1999.10.11", 1], //설정x 임시휴무일 ex : ["2024.10.11", 기간]
    ownerCall: "010-1234-5678",
    storeCall: "02-1234-5678",
    insta: "dassom_coffee", // null 입력시 insta 없음
    wifiId: "CAFE Dassom", // null 입력시 wifi 없음
    wifiPw: "a123456789", // null 입력시 wifi 없음
    toiletManLocation: "매장 1층",
    toiletManPw: "비밀번호 없음",
    toiletWomanLocation: "매장 1층",
    toiletWomanPw: "비밀번호 없음",
  },
  //가게 둘부턴 여기서 작성
];
export default data;
